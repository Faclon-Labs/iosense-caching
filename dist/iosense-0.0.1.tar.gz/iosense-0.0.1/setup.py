import setuptools

setuptools.setup(
    name = "iosense",
    version = "0.0.1",
    author = "Dhruti Mistry",
    description = "iosense data fetching library",
    packages = ["iosense"]
)